//: Playground - noun: a place where people can play

import UIKit

enum Velocidades : Int{
    case Apagado=0; case VelocidadBaja=20; case VelocidadMedia=50; case VelocidadAlta=120
    
    init(velocidadInicial: Velocidades){
        self = velocidadInicial
    }
    
    var name: String {
        get { return String(describing: self) }
    }
}


class Auto{
    
    var velocidad : Velocidades
    
    init(){
        velocidad = .Apagado
    }
    
    func cambioDeVelocidad(velocidadActual: Int) -> (actual: Int, velocidadEnCadena: String){
        let velocidadEnCadena:String = velocidad.name
        
        if (velocidadActual == 0){
            velocidad = .VelocidadBaja
        }else if (velocidadActual == 20){
            velocidad = .VelocidadMedia
        }else if (velocidadActual == 50){
            velocidad = .VelocidadAlta
        }else if (velocidadActual == 120){
            velocidad = .VelocidadMedia
        }
        
        return (velocidadActual, velocidadEnCadena)
    }
    
}

var auto = Auto();
var velocidadInicial = auto.velocidad

for _ in 0...20{
    let resultado = auto.cambioDeVelocidad(velocidadActual: auto.velocidad.rawValue);
    print(resultado.0,",",resultado.1)
}
